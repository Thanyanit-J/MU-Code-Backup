// THANYANIT JONGJITRAGAN 6188075
import java.io.*;
import java.util.ArrayList;

public class Sorting {
	static boolean viewProcess;
	static String[] read(String dataFile)
	{
		String[] data = null;
		BufferedReader br = null;
		try
		{
			br = new BufferedReader(new FileReader("C:\\Users\\TUNTUN\\Desktop\\Files\\Mahidol University\\OOP\\Lab13\\"+dataFile));
			String line;
			while ((line = br.readLine()) != null)
			{
				/*System.out.println(line);/**/
				data = line.split(" ");
			}
		}
		catch (IOException e) { e.printStackTrace(); }
		finally
		{
			try	{ if (br != null) br.close(); }
			catch (IOException e) { e.printStackTrace(); }
		}
		return data;
	}
	static void print(String[] str) {
		System.out.print("[");
		for(int i=0; i<str.length; i++)
		{
			System.out.print(str[i]+((i!=str.length-1)?", ":"]\n"));
		}
	}
	static void sort(String[] data) {
		int countPass=0;
		for(int y=0; y<data.length-1; y++)
		{
			if(data[y].compareTo(data[y+1])<0)
			{
				for(int search=y+1;search>0 ;search--)
				{
					if(data[search].compareTo(data[search-1])<0)
						break;
					
					String tmp=data[search];
					data[search]=data[search-1];
					data[search-1]=tmp;
				}
				// Process viewing
				countPass++;
				if(viewProcess) {
					System.out.print("Pass "+countPass+": ");
					print(data);
				}
				/**/
			}
		}
		if(!viewProcess) {
			System.out.print("Pass "+countPass+": ");
			print(data);
		}
	}
	
	static void bonus1(String[] data) {
		System.out.println("BONUS Option 1");
		ArrayList<String> word = new ArrayList();
		ArrayList<Integer> wordCount = new ArrayList();
		for(int i=0; i<data.length; i++)
		{
			int count=0;
			boolean isFound=false;
			
			// Check if the word exist the list
			for(int j=0; j<word.size(); j++)
			{
				if(data[i].equals(word.get(j))) {
					isFound=true;
					break;
				}
			}
			
			// if not exist, then add that word and its count
			if(isFound==false)
			{
				word.add(data[i]);
				for(int j=0; j<data.length; j++)
				{
					if(data[j].equals(word.get(i)))
						count++;
				}
				wordCount.add(count);
			}
				
		}
		// Find the position of the top 10 most frequent words
		int[] pos = {-1, -2, -3, -4, -5, -6, -7, -8, -9, -10};
		
		for(int i=0; (wordCount.size()>10)? i<10: i<wordCount.size(); i++)
		{
			int most = wordCount.get(0);
			for(int j=0; j<wordCount.size(); j++)
			{
				for(int k=0; k<i; k++)
				{
					if(wordCount.get(j) > most && j!=pos[k]) {
						most = wordCount.get(j);
						pos[i]=j;
					}
				}
			}
			System.out.print(pos[i]+" ");
		}
		
		for(int i=0; i<pos.length; i++)
		{
			if(pos[i]>-1)/**/
			//System.out.println(wordCount.size());
			System.out.println("["+word.get(i)+"] --- "+wordCount.get(i)+" word"+((wordCount.get(i)==1)?"":"s"));
		}
	}
	
	public static void main(String[] args) {
		String[] data = read("unsorted.txt");
		System.out.print("Original: "); print(data);
		viewProcess=true;
		sort(data);
		
		// CHALLENGING BONUS
		System.out.println("\n\n");
		String[] data2 = read("bonus1.txt");
		bonus1(data2);
	}

}
