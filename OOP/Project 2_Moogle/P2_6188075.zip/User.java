// Name: Thanyanit Jongjitragan
// Student ID: 6188075
// Section: 2

public class User {
	public int uid;
	
	public User(int _id){
		uid = _id;
	}
	
	public int getID(){
		return uid;
	}

}
