// Name:
// Student ID:
// Section: 

public class User {
	public int uid;
	
	public User(int _id){
		
		// YOUR CODE GOES HERE
		
	}
	
	public int getID(){
		
		// YOUR CODE GOES HERE
		
		return -1;
	}

}
