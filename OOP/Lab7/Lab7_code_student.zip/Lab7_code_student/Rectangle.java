
/*
 * The Rectangle class, subclass of Shape
 */
public class Rectangle extends Shape {
   // Private member variables
   //add your code here

   // Constructors
   public Rectangle()
   {
	  //add your code here

   }
   public Rectangle(String color, double length, double width) {
      //add your code here
   }

   @Override
   public String toString() {
      //add your code here
   }

   // Override the inherited getArea() to provide the proper implementation
   @Override
   public double getArea() {
      //add your code here
   }

   public double getArea(double length, double width) {
	   	 //add your code here
	   }
}
