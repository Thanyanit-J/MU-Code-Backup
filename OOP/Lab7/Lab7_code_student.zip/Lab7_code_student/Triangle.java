

/*  The structure of Triangle class is similar to Rectangle */
public class Triangle extends Shape {


   //add your code here

}
